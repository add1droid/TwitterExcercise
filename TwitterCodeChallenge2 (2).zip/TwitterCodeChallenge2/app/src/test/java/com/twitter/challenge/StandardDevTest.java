package com.twitter.challenge;

import org.assertj.core.data.Offset;
import org.junit.Test;

import static com.twitter.challenge.MainActivity.calculateSD;
import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.assertj.core.api.Java6Assertions.within;

public class StandardDevTest {
    @Test
    public void testStandardDev() {
    final Offset<Double> precision = within(0.01d);
    double[] sample = new double[]{25.0, 35.0, 45.0, 55.0, 65.0};
    double[] sample2 = new double[]{-2.0, 34.0, -6.0, 65.0, -28.0};

    assertThat(calculateSD(sample)).isEqualTo("14.14");
    assertThat(calculateSD(sample2)).isEqualTo("32.90");
}
}
