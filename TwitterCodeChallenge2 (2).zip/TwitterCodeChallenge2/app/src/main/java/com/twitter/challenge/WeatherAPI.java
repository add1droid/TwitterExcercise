package com.twitter.challenge;

import retrofit2.Call;
import retrofit2.http.GET;

public interface WeatherAPI {


    @GET("/current.json")
    Call<Post> getWeather();

}
