package com.twitter.challenge;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Day4 {
    @GET("/future_4.json")
    Call<Post> getDay4();
}
