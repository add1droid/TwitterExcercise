package com.twitter.challenge;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Day1 {
    @GET("/future_1.json")
    Call<Post> getDay1();
}
