package com.twitter.challenge;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Day5 {
    @GET("/future_5.json")
    Call<Post> getDay5();
}
