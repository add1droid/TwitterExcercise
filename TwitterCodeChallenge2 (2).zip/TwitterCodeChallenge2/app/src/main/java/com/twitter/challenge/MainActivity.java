package com.twitter.challenge;

import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;



import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private TextView temp;
    private TextView windspeed;
    private TextView nfd;
    private ImageView icon;
    private Button fd;
    double[] fivedays = new double[5];

    double[] results = new double[5];

    private float sWeath;
    private float sWspeed;
    private int sCloud;
    private String wtr;
    private String sp;
    private String next5;



    String BASE_URL = "https://twitter-code-challenge.s3.amazonaws.com";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        temp = findViewById(R.id.temperature);
        nfd = findViewById(R.id.nfd);
        windspeed = findViewById(R.id.windspeed);
        icon = findViewById(R.id.imageView);
        fd = findViewById(R.id.button);


        if (savedInstanceState != null) {
            Toast.makeText(this, "On State change", Toast.LENGTH_LONG).show();
            temp.setText(savedInstanceState.getString("savedWtr"));
            nfd.setText(savedInstanceState.getString("savedFd"));
            windspeed.setText(savedInstanceState.getString("savedSp"));

            if (savedInstanceState.getInt("savedInt") > 50) {
                icon.setVisibility(View.VISIBLE);
            }
        } else {
    // Execute retrofit calls and get data to set in TextViews
            results = getData();
            //Main Get Method for current.json
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            WeatherAPI api = retrofit.create(WeatherAPI.class);
            Call<Post> call = api.getWeather();


            call.enqueue(new Callback<Post>() {
                @Override
                public void onResponse(Call<Post> call, Response<Post> response) {
                    if (!response.isSuccessful()) {
                        Toast.makeText(getApplicationContext(), response.code(), Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Post w = response.body();
                    sWeath = w.weather.tempr;
                    sWspeed = w.wind.speed;
                    sCloud = w.clouds.cloudiness;

                    wtr = String.format("%.2f", sWeath) + "/" + String.format("%.2f", TemperatureConverter.celsiusToFahrenheit(sWeath));
                    temp.setText(wtr);

                    sp = Float.toString(sWspeed);
                    windspeed.setText(sp);

                    if (sCloud > 50) {
                        icon.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onFailure(Call<Post> call, Throwable t) {
                    // handle execution failures like no internet connectivity
                    Log.d("ERROR", t.getMessage());
                }
            });

            //Future 5 Day average
            fd.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    next5= calculateSD(results);
                    nfd.setText(next5);

                }

            });

        }
    }
    public static String calculateSD(double numArray[]) {

        double sum = 0.0, standardDeviation = 0.0;
        int length = numArray.length;

        for(double num : numArray) {
            sum += num;
        }
        double mean = sum/length;
        for(double num: numArray) {
            standardDeviation += Math.pow(num - mean, 2);
        }

        Double x= Math.sqrt(standardDeviation/length);

        String result = String.format("%.2f", x);

        return String.valueOf(result);
    }

    public  double[] getData() {

        //Retrofit for Get of future_1.json
        Retrofit retrofit1 = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        Day1 api1 = retrofit1.create(Day1.class);

        Call<Post> call1 = api1.getDay1();

        //Retrofit for Get of future_2.json
        Retrofit retrofit2 = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Day2 api2 = retrofit2.create(Day2.class);
        Call<Post> call2 = api2.getDay2();


        //Retrofit for Get of future_3.json
        Retrofit retrofit3 = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Day3 api3 = retrofit3.create(Day3.class);
        Call<Post> call3 = api3.getDay3();


        //Retrofit for Get of future_4.json
        Retrofit retrofit4 = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Day4 api4 = retrofit4.create(Day4.class);
        Call<Post> call4 = api4.getDay4();


        //Retrofit for Get of future_5.json
        Retrofit retrofit5 = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Day5 api5 = retrofit5.create(Day5.class);
        Call<Post> call5 = api5.getDay5();

        call1.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call1, Response<Post> response) {
                if(!response.isSuccessful()){
                    Toast.makeText(getApplicationContext(), response.code(), Toast.LENGTH_SHORT).show();
                    return;
                }
                Post posts = response.body();
                System.out.println("this is the response body"+ response);
                fivedays[0]=(double)posts.weather.tempr;
            }

            @Override
            public void onFailure(Call<Post> call1, Throwable t) {
                // handle execution failures like no internet connectivity
                Log.d("ERROR", t.getMessage());
            }
        });


        call2.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call2, Response<Post> response) {
                Post posts = response.body();
                fivedays[1]=(double)posts.weather.tempr;
            }

            @Override
            public void onFailure(Call<Post> call2, Throwable t) {

                // handle execution failures like no internet connectivity
                Log.d("ERROR", t.getMessage());
            }
        });


        call3.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call3, Response<Post> response) {
                Post posts = response.body();
                fivedays[2]=(double)posts.weather.tempr;
            }

            @Override
            public void onFailure(Call<Post> call3, Throwable t) {

                // handle execution failures like no internet connectivity
                Log.d("ERROR", t.getMessage());
            }
        });


        call4.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call4, Response<Post> response) {
                Post posts = response.body();
                fivedays[3]=(double)posts.weather.tempr;
            }

            @Override
            public void onFailure(Call<Post> call4, Throwable t) {

                // handle execution failures like no internet connectivity
                Log.d("ERROR", t.getMessage());
            }
        });

        call5.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call5, Response<Post> response) {
                Post posts = response.body();
                fivedays[4]=(double)posts.weather.tempr;
            }

            @Override
            public void onFailure(Call<Post> call5, Throwable t) {

                // handle execution failures like no internet connectivity
                Log.d("ERROR", t.getMessage());
            }
        });
        return fivedays;
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("savedWtr", wtr);
        outState.putString("savedSp", sp);
        outState.putInt("savedInt", sCloud);
        outState.putString("savedFd", next5);

    }
}
