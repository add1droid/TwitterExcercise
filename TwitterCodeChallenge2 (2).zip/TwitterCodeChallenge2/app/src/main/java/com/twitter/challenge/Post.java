package com.twitter.challenge;

import com.google.gson.annotations.SerializedName;

public class Post {

    @SerializedName("coord")
    public Coord coord;
    @SerializedName("wind")
    public Wind wind;
    @SerializedName("rain")
    public Rain rain;
    @SerializedName("clouds")
    public Clouds clouds;
    @SerializedName("name")
    public String name;
    @SerializedName("weather")
    public Weather weather;

}

class Weather {
    @SerializedName("temp")
    public float tempr;
    @SerializedName("pressure")
    public float pressure;
    @SerializedName("humidity")
    public int humidity;

}

class Clouds {
    @SerializedName("cloudiness")
    public int cloudiness;
}

class Rain {
    @SerializedName("3h")
    public float h3;
}

class Wind {
    @SerializedName("speed")
    public float speed;
    @SerializedName("deg")
    public float deg;
}


class Coord {
    @SerializedName("lon")
    public float lon;
    @SerializedName("lat")
    public float lat;
}
