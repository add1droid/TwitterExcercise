package com.twitter.challenge;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Day3 {
    @GET("/future_3.json")
    Call<Post> getDay3();
}
